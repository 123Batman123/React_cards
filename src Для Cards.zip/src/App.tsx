import './App.css'
import { CardList } from './components/CardList'

function App() {
  return (
    <CardList/>
  )
}

export default App
